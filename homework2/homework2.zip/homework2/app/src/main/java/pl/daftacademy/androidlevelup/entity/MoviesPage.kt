package pl.daftacademy.androidlevelup.entity

data class MoviesPage(val movies: List<Movie>)